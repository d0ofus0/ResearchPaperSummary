"""
Modified script to retrieve 10 papers from the quant-ph category and generate both regular and extended summaries.
"""
import os
import json
from datetime import datetime
import arxiv
import time
from pdf_extractor import get_full_paper_text
import extractive_summarizer

def create_output_directory():
    """
    Create output directory for storing paper summaries.
    
    Returns:
        str: Path to the output directory
    """
    output_dir = os.path.join(os.getcwd(), "paper_summaries_quant_ph_extended")
    os.makedirs(output_dir, exist_ok=True)
    return output_dir

def datetime_to_string(obj):
    """
    Convert datetime objects to ISO format strings for JSON serialization.
    
    Args:
        obj: Object to convert
        
    Returns:
        str: ISO format string if obj is datetime, otherwise obj
    """
    if isinstance(obj, datetime):
        return obj.isoformat()
    return obj

def get_paper_details(paper):
    """
    Extract relevant details from a paper.
    
    Args:
        paper: ArXiv paper object
        
    Returns:
        dict: Dictionary containing paper details
    """
    return {
        'title': paper.title,
        'authors': [author.name for author in paper.authors],
        'summary': paper.summary,
        'published': paper.published,
        'updated': paper.updated,
        'pdf_url': paper.pdf_url,
        'entry_id': paper.entry_id,
        'doi': paper.doi,
        'categories': paper.categories
    }

def get_paper_text(paper):
    """
    Get the full text of a paper by downloading and parsing the PDF.
    
    Args:
        paper: ArXiv paper object
        
    Returns:
        str: The paper's text content
    """
    print(f"Downloading and extracting text from PDF: {paper.pdf_url}")
    
    # Download and extract text from the PDF
    full_text = get_full_paper_text(paper.pdf_url)
    
    # If PDF extraction fails, fall back to the abstract
    if not full_text or len(full_text.strip()) < len(paper.summary):
        print("PDF extraction failed or returned less text than the abstract. Using abstract as fallback.")
        return paper.summary
    
    print(f"Successfully extracted {len(full_text)} characters from the PDF.")
    return full_text

def retrieve_quant_ph_papers(max_results=10):
    """
    Retrieve papers exclusively from the quant-ph category.
    
    Args:
        max_results (int): Maximum number of papers to retrieve
        
    Returns:
        list: List of dictionaries containing paper details and summaries
    """
    # Create output directory
    output_dir = create_output_directory()
    
    # Search for papers in quant-ph category
    print(f"Searching for papers in the quant-ph category...")
    
    client = arxiv.Client()
    search = arxiv.Search(
        query='cat:quant-ph',
        max_results=max_results,
        sort_by=arxiv.SortCriterion.SubmittedDate
    )
    
    papers = []
    for result in client.results(search):
        papers.append(result)
        # Be nice to the API with a small delay
        time.sleep(0.1)
    
    if not papers:
        print("No papers found.")
        return []
    
    print(f"Found {len(papers)} papers. Processing...")
    
    # Process each paper
    results = []
    for i, paper in enumerate(papers):
        print(f"Processing paper {i+1}/{len(papers)}: {paper.title}")
        print(f"Categories: {', '.join(paper.categories)}")
        print(f"Entry ID: {paper.entry_id}")
        
        # Get paper details
        paper_details = get_paper_details(paper)
        
        # Convert datetime objects to strings
        for key, value in paper_details.items():
            paper_details[key] = datetime_to_string(value)
        
        # Get paper text (now extracts text from PDF)
        paper_text = get_paper_text(paper)
        
        # Generate a brief summary (for the card view)
        print("Generating brief summary...")
        brief_summary = extractive_summarizer.summarize_paper_sections(paper_text, num_sentences=3)
        
        # Generate an extended summary (for the detailed view)
        print("Generating extended summary...")
        extended_summary = extractive_summarizer.summarize_paper_sections(paper_text, num_sentences=10)
        
        # Add summaries to paper details
        paper_details['summary_brief'] = brief_summary
        paper_details['summary_extended'] = extended_summary
        
        # Save to file
        filename = f"paper_{i+1}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        filepath = os.path.join(output_dir, filename)
        
        with open(filepath, 'w') as f:
            json.dump(paper_details, f, indent=2)
        
        print(f"Saved paper details and summaries to {filepath}")
        
        results.append(paper_details)
    
    print(f"Processed {len(results)} papers.")
    return results

if __name__ == "__main__":
    # Retrieve and process papers
    papers = retrieve_quant_ph_papers(max_results=10)
    
    # Print summary of results
    if papers:
        print("\nSummary of processed papers:")
        for i, paper in enumerate(papers):
            print(f"\n{i+1}. {paper['title']}")
            print(f"   Authors: {', '.join(paper['authors'])}")
            print(f"   Categories: {', '.join(paper['categories'])}")
            print(f"   Published: {paper['published']}")
            print(f"   Entry ID: {paper['entry_id']}")
            print(f"   Brief summary length: {len(paper['summary_brief'].split())} words")
            print(f"   Extended summary length: {len(paper['summary_extended'].split())} words")
