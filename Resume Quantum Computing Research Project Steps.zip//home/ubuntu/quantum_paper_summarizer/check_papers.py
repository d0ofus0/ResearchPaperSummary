import arxiv
import time

def get_recent_papers(max_results=10):
    client = arxiv.Client()
    search = arxiv.Search(
        query='cat:quant-ph',
        max_results=max_results,
        sort_by=arxiv.SortCriterion.SubmittedDate
    )
    
    papers = []
    for result in client.results(search):
        papers.append(result)
        # Be nice to the API with a small delay
        time.sleep(0.1)
    
    print(f"Found {len(papers)} papers:")
    for i, paper in enumerate(papers):
        print(f"{i+1}. {paper.title}")
        print(f"   Categories: {', '.join(paper.categories)}")
        print(f"   Entry ID: {paper.entry_id}")
        print()
    
    return papers

if __name__ == "__main__":
    get_recent_papers(10)
